# PrimeData — Airtime & Data Recharge App

Full-stack VTU (Virtual Top-Up) platform: airtime + data recharge, wallet system, guest checkout, Paystack payments, VTpass fulfillment. Ships in **MOCK MODE** — fully clickable right now with zero API keys. Flip one flag to go live.

## What's inside
- `backend/` — Node + Express API, SQLite (built into Node, no native install needed), JWT auth, Paystack + VTpass integration layer
- `frontend/index.html` — single-file app (no build step), Hormozi-style buy flow, wallet, guest checkout, transaction history

## Run it locally

**1. Backend**
```bash
cd backend
npm install
cp .env.example .env    # already done if you got this from me — check MOCK_MODE=true
node server.js
```
Runs on `http://localhost:4000`. You'll see `MOCK_MODE=true` in the console — that means Paystack and VTpass calls are faked so you can test the entire flow without real keys.

**2. Frontend**
Just open `frontend/index.html` in a browser. (Or serve it: `npx serve frontend` if you want a local server instead of `file://`.)

## What works right now (mock mode)
- Register / Login (real JWT auth, real password hashing, real SQLite database)
- Guest checkout (no account needed)
- Fund wallet (fake Paystack checkout, auto-confirms)
- Buy airtime/data from wallet or "card" — across Nigeria (VTpass), Ghana/Kenya/South Africa/Egypt (Reloadly)
- Auto-detect user's country by IP, with manual override always available
- Free 1GB granted automatically after a user's first paid recharge (retention reward, not signup bait)
- Margin-protected cashback on data purchases — 15% of YOUR margin (not of sale price), capped, with 30-day expiry that's actually enforced (hourly sweep claws back unspent expired cashback)
- Transparent Receipt — every data purchase response includes the exact margin earned and cashback given, so you can show customers your math openly
- Predictive recharge — `/api/predictions` detects repeat purchase patterns per network/plan and flags when a user is likely running low
- Auto-recharge scheduling — set-and-forget recurring top-ups, checked every 60 seconds by a background job
- WhatsApp bot (mock) — text "RECHARGE 500 MTN" or "BALANCE" to a registered number and it executes through the real wallet pipeline
- Send Abroad — fund a recharge for a phone number in a different country than your own, with a recipient name on the receipt (the diaspora/cross-border use case)
- Transaction history per user

Everything is **real** except the outbound calls to Paystack, VTpass, Reloadly, and WhatsApp — those return realistic fake responses so the UI/logic behaves exactly like production.

## Going live — 3 steps

**1. Get your keys**
- Paystack: https://dashboard.paystack.com/#/settings/developer — grab your secret + public key
- VTpass: https://vtpass.com/ — register, get API key + secret key (they also have a sandbox at sandbox.vtpass.com for testing real calls before going fully live)

**2. Drop them into `backend/.env`**
```
MOCK_MODE=false
PAYSTACK_SECRET_KEY=sk_live_xxxxx
PAYSTACK_PUBLIC_KEY=pk_live_xxxxx
VTPASS_API_URL=https://vtpass.com/api
VTPASS_USERNAME=your_email
VTPASS_PASSWORD=your_password
VTPASS_API_KEY=your_key
VTPASS_SECRET_KEY=your_secret
RELOADLY_API_URL=https://topups.reloadly.com
RELOADLY_CLIENT_ID=your_client_id
RELOADLY_CLIENT_SECRET=your_client_secret
WHATSAPP_ACCESS_TOKEN=your_token
WHATSAPP_PHONE_NUMBER_ID=your_phone_id
```

For the WhatsApp bot specifically: you'll also need to register a webhook URL with Meta pointing to `https://yourdomain.com/api/whatsapp/webhook` so incoming messages actually reach this code — Meta's docs walk through that step at the link above.

**3. Restart the server.** That's it — same code, same UI, now moving real money and delivering real airtime/data.

## Important before real launch
- **Frontend payment redirect**: right now, in mock mode, the frontend "auto-confirms" guest/card payments instantly for demo purposes. In live mode, you need to actually redirect the user to `data.payRes.data.authorization_url` (the real Paystack checkout page), then call `/api/buy/confirm` when they're redirected back. I left a comment in the code (`handlePurchaseResponse` in `index.html`) marking exactly where to wire this in.
- **Webhooks**: for production, also set up a Paystack webhook hitting a new `/api/webhook/paystack` route as a backup confirmation path, in case the user closes the tab before returning from checkout. I didn't build this yet — say the word and I'll add it.
- **Data plans**: the data plans (`backend/vtpass.js`) are sample prices. Once you have real VTpass keys, call their `/service-variations` endpoint to pull live plans and prices per network, and swap the hardcoded `DATA_PLANS` object for that.
- **JWT_SECRET**: change this in `.env` to something long and random before going live. Don't ship the default.
- **CORS**: currently wide open (`cors()` with no config) for ease of local testing. Lock this down to your actual domain before launch.
- **Database**: SQLite is fine to start and will comfortably handle real volume for a while. When you're ready to scale past one server, migrate to Postgres — the query layer is simple enough that it's a quick swap.

## Stack
- Backend: Node.js, Express, JWT, bcrypt, built-in `node:sqlite`
- Frontend: vanilla HTML/CSS/JS (zero build tools, zero dependencies — runs anywhere)
- Payments: Paystack
- Fulfillment: VTpass
